<?php

class form{


	public function makeform(){

		$r ='<section>';
		$r .= '<form action = "action.php" method = "post"  enctype="multipart/form-data">';
		$r .= '<legend>The Form</legend>';
		$r .= '<fieldset?>';
		$r .= '<label>Name:</label>';
		$r .= '<input type = "text" value = "" name = "name" required="true" />';
		$r .= '<br />';
		$r .= '<label>E-Mail:</label>';
		$r .= '<input type = "text" value = "" name = "email" required="true" />';
		$r .= '<br />';
		$r .= '<label>Photo:</label>';
		$r .= '<input type = "file" value = "" name = "photo" required="true" />';
		$r .= '<br />';
		$r .= '<input type = "submit" value ="Submit" class = "button" />';
		$r .= '</fieldset>';
		$r .= '</form>';
		$r .= '</section>';


		return $r;

	}


	public function validateform(){

		$errormessage = '';
		$error = false;		

		if ( strlen ( $this -> name ) <= 0 ){
			$error = true;
			$errormessage .= 'No name';
		}

		if (!filter_var($this -> email , FILTER_VALIDATE_EMAIL)){
			$error = true;
			$errormessage .= ' Email error';
		}

		return array('error' => $error, 'errormessage' => $errormessage);


		}


	public function createdbrecord(){

		$query = 'insert into thedata
					(the_name, email, photo)
					values (
						"' . $this -> name . '"
						, "' . $this -> email . '"
						, "' . $this -> photo . '")
						';


		db::connectdb($query);

		return true;
	}


	function readdata(){

		$query = 'select * from thedata';
		
		$results_array = array();	

		$result = db::connectdb($query);

		while($row = $result->fetch_assoc()){
 	   	$results_array[]= $row;
		}
		return $results_array;

		}


	function showexisting(){

		$r = '<section>';
		$r .= '<table>';	
		// print_r($this -> existingdata);
		$r .= '<tr><th>Name</th><th>E-Mail</th><th>Photo</th></tr>';
		foreach( $this -> existingdata as $data ){

			$r .= '<tr><td>' . $data["the_name"] . '</td>
					<td>' . $data["email"] . '</td>
					<td><a href = "tmp/' .  $data["photo"] . '">' . $data["photo"] . '</a></td>

				</tr>';

		}

		$r .= '</table>';
		$r .= '</section>';

		return $r;
	}


	function __get($property){

		if (isset($this->$property))
		return $this->$property;
	}


	function __set($property, $value){

		$this->$property = $value;
	}	


}