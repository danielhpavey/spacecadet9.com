<?php

class footer{

	public function makefooter(){


		$r ='';
		$r .= '<footer>
				</footer>
 				</body>
			 	</html>';

		return $r;

	}


}