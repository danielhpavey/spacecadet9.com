<?php

class head{


	public function makehead(){

		$r = '';
		$r .= '<!DOCTYPE html>   
		<html lang="en">
		<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
		<title>Task for Toucan</title>
		<meta name="description" content="">
		<meta name="keywords" content="" />
		<meta name="author" content="">
		<meta name="viewport" content="width=device-width; initial-scale=1.0">
		<link rel="stylesheet" href="styles.css">
		</head>
		<body>
		<header>
		<h1>Task for Toucan</h1>
		</header>';


		return $r;

	}
	
}