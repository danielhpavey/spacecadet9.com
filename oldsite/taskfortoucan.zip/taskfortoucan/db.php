<?php

class db{


	public static function connectdb($query){
		
		$db = new mysqli("localhost", "root","root","taskfortoucan", "3306"); 
		$result = $db->query($query);

		return $result;

		$db->close();

	}


}