<?php

include ('form.php');
include ('db.php');

if ( isset ( $_POST )){

	$processform = new form();
	$processform -> name = $_POST["name"];
	$processform -> email = $_POST["email"];
	$processform -> photo = $_FILES["photo"]["name"];

	$formvalidate =  $processform -> validateform();
	if ( $formvalidate["error"] == true){
		echo $formvalidate["errormessage"];
	} else {

		$processform -> createdbrecord();
		move_uploaded_file($_FILES["photo"]["tmp_name"], realpath(dirname(__FILE__)) . '/tmp/' . $_FILES["photo"]["name"]);


		$header = 'index.php';
		header("Location: $header");

	}



}
