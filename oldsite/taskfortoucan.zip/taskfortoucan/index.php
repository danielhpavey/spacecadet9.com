<?php
include ('head.php');
include ('form.php');
include ('db.php');


$head = new head();
echo $head -> makehead();

$form = new form();
echo $form -> makeform();

$existingdata = new form();
$thedata = $existingdata -> readdata();

$returnexisting = new form();
$returnexisting -> existingdata = $thedata;
echo $returnexisting -> showexisting();

include ('footer.php');
$foot = new footer();
echo $foot -> makefooter();

?>